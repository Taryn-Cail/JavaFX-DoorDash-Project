import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class Demo1 extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("JavaFX Game");

        // Create a StackPane as the root node
        StackPane root = new StackPane();

        // Set the background color to light blue
        root.setStyle("-fx-background-color: lightblue;");

        // Create the scene with the StackPane as the root node
        Scene scene = new Scene(root, 800, 600);

        // Set the scene for the primaryStage
        primaryStage.setScene(scene);

        // Show the primaryStage
        primaryStage.show();
    }
}
