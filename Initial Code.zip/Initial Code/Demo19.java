import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class Demo19 extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Create an HBox for the buttons with spacing
        HBox buttonBox = new HBox(10); // 10 pixels spacing (adjust as needed)
        buttonBox.setAlignment(Pos.CENTER);

        // Load smaller door images
        Image door1Image = new Image("door1.png", 50, 50, true, true);
        Image door2Image = new Image("door2.png", 50, 50, true, true);
        Image door3Image = new Image("door3.png", 50, 50, true, true);
        Image door4Image = new Image("door4.png", 50, 50, true, true);

        // Create buttons
        Button door1 = createButton("door1", door1Image, "video1.mp4", "video2.mp4");
        Button door2 = createButton("door2", door2Image, "video3.mp4", "video4.mp4");
        Button door3 = createButton("door3", door3Image, "video5.mp4", "video6.mp4");
        Button door4 = createButton("door4", door4Image, "video7.mp4", "video8.mp4");

        // Add buttons to the HBox
        buttonBox.getChildren().addAll(door1, door2, door3, door4);

        // Create a BorderPane to hold the HBox
        BorderPane borderPane = new BorderPane();
        borderPane.setCenter(buttonBox);
        borderPane.setPadding(new Insets(20)); // Padding around the border pane

        // Create the scene with the BorderPane as the root node
        Scene scene = new Scene(borderPane); // Using final dimensions

        // Set the scene for the primaryStage
        primaryStage.setScene(scene);
        primaryStage.setTitle("Door Dash");

        // Show the primaryStage
        primaryStage.show();
    }

    // Create button method
    private Button createButton(String buttonText, Image buttonImage, String video1, String video2) {
        Button button = new Button(buttonText, new ImageView(buttonImage));
        button.setPrefSize(50, 50); // Set button size

        // Handle button click
        button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                // Play videos associated with the door (replace with your video playback implementation)
                playVideo(video1);
                playVideo(video2);
            }
        });

        return button;
    }

    // Placeholder method for video playback
    private void playVideo(String videoFile) {
        // Replace this with your video playback logic
        System.out.println("Playing video: " + videoFile);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
