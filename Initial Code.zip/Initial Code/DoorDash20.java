import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.layout.StackPane;
import javafx.geometry.Insets;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import java.io.File;
import javafx.scene.control.Label;

/********************************************************************************************************************
 * CS1083 - JavaFX Project - Door Dash
 * 
 * Purpose: To create a JavaFX game for Dr McNally's fortnite stream.
 * 
 * Game: Door Dash
 * 
 * How to Play: At the start of each round the player selects a door, once chosen, 
 *              the door will reveal what’s behind it, the options are -1 coin, 0 coins , +1 coin, +2 coins.
 *               
 *              Once the player makes it through all five rounds of doors, they can choose to cash out 
 *              their jar of coins and end the game, or they can forfeit their earnings and attempt to win higher 
 *              prizes in the Lightning Round. 
 *               
 *              During the lighting round there is a set of four doors, 
 *              behind two doors is a Lose Everything option, behind another is a Keep your Current Jar, 
 *              and behind the last Double’s your Coins. 
 *
 * 
 * @authors - Zach Davis, Nicolas Serrano, Taryn Cail
 * @version - 20.0
 * @date - Winter 2024
 *********************************************************************************************************************/

public class DoorDash20 extends Application 
{
    // Declaring my Instance Data
    private static int points = 0;
    private static int round = 1;
    Label pointsLabel;
    Label roundLabel;
    
    @Override
    public void start(Stage primaryStage) 
    {
        // Creating the main BorderPane for the layout
        BorderPane borderPane = new BorderPane();
        borderPane.setStyle("-fx-background-color: lightblue;");

        // Create an HBox for the door buttons with spacing
        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER);

        /******************************************
         * Creating the Door Images
         *****************************************/
        Image door1Image = new Image("door1.png");
        ImageView door1ImageView = new ImageView(door1Image);
        Image door2Image = new Image("door2.png");
        ImageView door2ImageView = new ImageView(door2Image);
        Image door3Image = new Image("door3.png");
        ImageView door3ImageView = new ImageView(door3Image);
        Image door4Image = new Image("door4.png");
        ImageView door4ImageView = new ImageView(door4Image);
        
        
        /*****************************************
         * Creating the Title Image
         ****************************************/
        Image titleImage = new Image("title.png");
        ImageView titleImageView = new ImageView(titleImage);
        titleImageView.setFitWidth(775);
        titleImageView.setFitHeight(175);
        
        
        /*****************************************
         * Creating the Jar 0 Image
         *****************************************/
        Image jar0Image = new Image("jar0.png");
        ImageView jar0ImageView = new ImageView(jar0Image);
        jar0ImageView.setFitWidth(220);
        jar0ImageView.setFitHeight(300);
        
        
        /******************************************
         * Creating Scoresheet Image
         *****************************************/
        Image scoresheetImage = new Image("scoresheet.png");
        ImageView scoresheetImageView = new ImageView(scoresheetImage);
        scoresheetImageView.setFitWidth(200);
        scoresheetImageView.setFitHeight(250);
        
        
        /******************************************
         * Creating the reset, reveal, end, next 
         * and lightning round button images
         ******************************************/
        Image resetImage = new Image("reset.png");
        ImageView resetImageView = new ImageView(resetImage);
        Image revealImage = new Image("reveal.png");
        ImageView revealImageView = new ImageView(revealImage);
        Image endImage = new Image("end.png");
        ImageView endImageView = new ImageView(endImage);
        Image nextImage = new Image("next.png");
        ImageView nextImageView = new ImageView(nextImage);
        Image lightningImage = new Image("lightningButton.png");
        ImageView lightningImageView = new ImageView(lightningImage);
        // Setting the lightning buttons size to a specfific size
        lightningImageView.setFitWidth(150);
        lightningImageView.setFitHeight(100);
        
        
        /******************************************
         * Creating the Door Buttons
         *****************************************/
        // Button 1
        Button door1 = createButton("door1", "video1.mp4");
        door1.setGraphic(door1ImageView);
        door1ImageView.setFitWidth(door1.getPrefWidth());
        door1ImageView.setFitHeight(door1.getPrefHeight());
        // Button 2
        Button door2 = createButton("door2", "video2.mp4");
        door2.setGraphic(door2ImageView);
        door2ImageView.setFitWidth(door2.getPrefWidth());
        door2ImageView.setFitHeight(door2.getPrefHeight());
        // Button 3
        Button door3 = createButton("door3", "video3.mp4");
        door3.setGraphic(door3ImageView);
        door3ImageView.setFitWidth(door3.getPrefWidth());
        door3ImageView.setFitHeight(door3.getPrefHeight());
        // Button 4
        Button door4 = createButton("door4", "video4.mp4");
        door4.setGraphic(door4ImageView);
        door4ImageView.setFitWidth(door4.getPrefWidth());
        door4ImageView.setFitHeight(door4.getPrefHeight());
        // Add buttons to the HBox
        buttonBox.getChildren().addAll(door1, door2, door3, door4);

        
        /******************************************
         * Creating the Jar Buttons
         *****************************************/
        // Creating the subtract button
        Button subtract1 = new Button("-1");
        subtract1.setPrefWidth(35);
        subtract1.setPrefHeight(35);
        subtract1.setStyle("-fx-font-weight: bold;");
        subtract1.setOnAction(event ->
        {
            // Changing the points label by -1
            points--;
            pointsLabel.setText("Current Score: " + points);
            
            // Creating a new stage for the video player with a title
            Stage videoStage = new Stage();
            videoStage.setTitle("You lost 1 point!");
            
            // Setting up the media player for the video
            String videoFile = "JarEmpty.mp4";
            Media media = new Media(new File(videoFile).toURI().toString());
            MediaPlayer mediaPlayer = new MediaPlayer(media);
            MediaView mediaView = new MediaView(mediaPlayer);
            
            // Setting the width and height of the mediaView
            mediaView.setFitWidth(800);
            mediaView.setFitHeight(500);
            
            // Creating a StackPane in order to center the video
            StackPane mediaPane = new StackPane();
            mediaPane.getChildren().add(mediaView);
            mediaPane.setStyle("-fx-background-color: rgb(161, 217, 231);");
            
            // Setting the scene and showing the video
            Scene scene = new Scene(mediaPane);
            videoStage.setScene(scene);
            mediaPlayer.play();
            videoStage.show();
        }
        );
        
        // Creating the zero button button
        Button zeroButton = new Button("0");
        zeroButton.setPrefWidth(35);
        zeroButton.setPrefHeight(35);
        zeroButton.setStyle("-fx-font-weight: bold;");
        zeroButton.setOnAction(event ->
        {
            // This button does not change the points therefore there is no
            // change to the label code here.
            
            // Creating a new stage for the video player with a title
            Stage videoStage = new Stage();
            videoStage.setTitle("You got 0 points!");
            
            // Setting up the media player for the video
            String videoFile = "JarZero.mp4";
            Media media = new Media(new File(videoFile).toURI().toString());
            MediaPlayer mediaPlayer = new MediaPlayer(media);
            MediaView mediaView = new MediaView(mediaPlayer);
            
            // Setting the width and height of the mediaView
            mediaView.setFitWidth(800);
            mediaView.setFitHeight(500);
            
            // Creating a StackPane in order to center the video
            StackPane mediaPane = new StackPane();
            mediaPane.getChildren().add(mediaView);
            mediaPane.setStyle("-fx-background-color: rgb(161, 217, 231);");
            
            // Setting the scene and showing the video
            Scene scene = new Scene(mediaPane);
            videoStage.setScene(scene);
            mediaPlayer.play();
            videoStage.show();
        }
        );
        
        // Creating the add1 button button
        Button add1 = new Button("+1");
        add1.setPrefWidth(35);
        add1.setPrefHeight(35);
        add1.setStyle("-fx-font-weight: bold;");
        add1.setOnAction(event ->
        {
            // Changing the points label by +1
            points++;
            pointsLabel.setText("Current Score: " + points);
            
            // Creating a new stage for the video player with a title
            Stage videoStage = new Stage();
            videoStage.setTitle("You got 1 point!");
            
            // Setting up the media player for the video
            String videoFile = "JarFill.mp4";
            Media media = new Media(new File(videoFile).toURI().toString());
            MediaPlayer mediaPlayer = new MediaPlayer(media);
            MediaView mediaView = new MediaView(mediaPlayer);
            
            // Setting the width and height of the mediaView
            mediaView.setFitWidth(800);
            mediaView.setFitHeight(500);
            
            // Creating a StackPane in order to center the video
            StackPane mediaPane = new StackPane();
            mediaPane.getChildren().add(mediaView);
            mediaPane.setStyle("-fx-background-color: rgb(161, 217, 231);");
            
            // Setting the scene and showing the video
            Scene scene = new Scene(mediaPane);
            videoStage.setScene(scene);
            mediaPlayer.play();
            videoStage.show();
        }
        );
        
        // Creating the add1 button button
        Button add2 = new Button("+2");
        add2.setPrefWidth(35);
        add2.setPrefHeight(35);
        add2.setStyle("-fx-font-weight: bold;");
        add2.setOnAction(event ->
        {
            // Changing the points label by +2
            points++;
            points++;
            pointsLabel.setText("Current Score: " + points);
            
            // Creating a new stage for the video player with a title
            Stage videoStage = new Stage();
            videoStage.setTitle("You got 2 points!");
            
            // Setting up the media player for the video
            String videoFile = "JarFill2.mp4";
            Media media = new Media(new File(videoFile).toURI().toString());
            MediaPlayer mediaPlayer = new MediaPlayer(media);
            MediaView mediaView = new MediaView(mediaPlayer);
            
            // Setting the width and height of the mediaView
            mediaView.setFitWidth(800);
            mediaView.setFitHeight(500);
            
            // Creating a StackPane in order to center the video
            StackPane mediaPane = new StackPane();
            mediaPane.getChildren().add(mediaView);
            mediaPane.setStyle("-fx-background-color: rgb(161, 217, 231);");
            
            // Setting the scene and showing the video
            Scene scene = new Scene(mediaPane);
            videoStage.setScene(scene);
            mediaPlayer.play();
            videoStage.show();
        }
        );
        
        
        
        
        /********************************************
         * Creating a label that displays the current
         * amount of points the player has.
         ********************************************/
        pointsLabel = new Label();
        pointsLabel.setText("Current Score: " + points);
        pointsLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");
        
        
        
        
        /********************************************
         * Creating a label that displays the current
         * round the player is on.
        ********************************************/
        roundLabel = new Label();
        roundLabel.setText("Current Round: " + round);
        roundLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");
         
        
        
        
        /********************************************
        * Creating the Lightning Round Button
        ********************************************/
        Button lightningRoundButton = new Button();
        lightningRoundButton.setGraphic(lightningImageView);
        
        lightningRoundButton.setOnAction(event -> lightningRound());
        
        
        
        /********************************************
         * Creating the HBox (jarButtons) to hold the jar 
         * buttons, a VBox (leftImagesBox) to hold the 
         * scoresheet, and another HBox (rightImagesBox) 
         * to hold the jar and HBox.
         ********************************************/
        // Create a HBox to hold the jar buttons
        HBox jarButtons = new HBox(10);
        // Placing the buttons in the HBox
        jarButtons.getChildren().addAll(subtract1, zeroButton, add1, add2);
        jarButtons.setAlignment(Pos.CENTER);
        
        // Create an VBox to hold the Jar
        VBox rightImagesBox = new VBox(10);
        // Placing the HBox and jar image in the VBox
        rightImagesBox.getChildren().addAll(roundLabel, pointsLabel, jarButtons, jar0ImageView);
        // Center aligning the jar, buttons and label and adding spacing to it
        rightImagesBox.setAlignment(Pos.CENTER);
        rightImagesBox.setPadding(new Insets(20, 20, 20, 0));
        
        // Create a VBox to hold the scoresheet
        VBox leftImagesBox = new VBox(10);
        // Placing the scoresheet in the VBox
        leftImagesBox.getChildren().addAll(lightningRoundButton, scoresheetImageView);
        // Center aligning the scoresheet and adding spacing to it
        leftImagesBox.setAlignment(Pos.CENTER);
        leftImagesBox.setPadding(new Insets(20, 20, 20, 20));
        
        

        
        
        /********************************************
         * Creating the reset, reveal, end and next
         * buttons.
         ********************************************/
        // Reset Button
        Button resetButton = createBottomButton();
        // Setting the Reset Buttons graphic
        resetButton.setGraphic(resetImageView);
        // Setting the Reset Buttons size
        resetImageView.setFitWidth(resetButton.getPrefWidth());
        resetImageView.setFitHeight(resetButton.getPrefHeight());
        
        // Reveal Button        
        Button revealButton = createBottomButton();
        // Setting the Reveal Buttons graphic
        revealButton.setGraphic(revealImageView);
        // Setting the Reveal Buttons size
        revealImageView.setFitWidth(revealButton.getPrefWidth());
        revealImageView.setFitHeight(revealButton.getPrefHeight());
        
        // End Button
        Button endButton = createBottomButton();
        // Setting the End Buttons graphic
        endButton.setGraphic(endImageView);
        // Setting the End Buttons size
        endImageView.setFitWidth(endButton.getPrefWidth());
        endImageView.setFitHeight(endButton.getPrefHeight());
        
        // Next Button
        Button nextButton = createBottomButton();
        // Setting the Next Buttons graphic
        nextButton.setGraphic(nextImageView);
        // Setting the Next Buttons size
        nextImageView.setFitWidth(nextButton.getPrefWidth());
        nextImageView.setFitHeight(nextButton.getPrefHeight());

        
        

        // Create an HBox for the buttons in the bottom part
        HBox bottomButtonBox = new HBox(20);
        bottomButtonBox.getChildren().addAll(resetButton, revealButton, endButton, nextButton);
        bottomButtonBox.setAlignment(Pos.CENTER);
        bottomButtonBox.setPadding(new Insets(10, 10, 10, 10));

        // Adding everything to the Borderpane
        borderPane.setTop(titleImageView);
        BorderPane.setMargin(titleImageView, new Insets(20, 0, 0, 0));
        BorderPane.setAlignment(titleImageView, Pos.CENTER);

        borderPane.setCenter(buttonBox);
        borderPane.setLeft(leftImagesBox);
        borderPane.setRight(rightImagesBox);
        borderPane.setBottom(bottomButtonBox);
        BorderPane.setAlignment(bottomButtonBox, Pos.CENTER);
        
        // Create the scene with the BorderPane as the main layout
        Scene myScene = new Scene(borderPane, 1450, 850);

        // Set the scene for the primaryStage
        primaryStage.setScene(myScene);
        primaryStage.setTitle("Door Dash");
        primaryStage.setWidth(1490);
        primaryStage.setHeight(810);
        primaryStage.setResizable(false);
        primaryStage.show();
    }

    /**********************************************************************
     * Method: Create Button
     * 
     * Purpose: To create the buttons for the doors that hold a string 
     *          name and play a video when clicked.
     *********************************************************************/
    private Button createButton(String buttonText, String video1) 
    {
        Button button = new Button(buttonText);

        // Set dimensions
        button.setPrefSize(200, 400);
        button.setStyle("-fx-background-color: lightblue;");

        // Handle button click
        button.setOnAction(new EventHandler<ActionEvent>() 
        {
            @Override
            public void handle(ActionEvent event) 
            {
                playVideo(video1);
            }
        }
        );
        return button;
    }
    
    /**********************************************************************
     * Method: Create Bottom Button
     * 
     * Purpose: To create the buttons for below the doors that have a blue 
     *          background until an image is inserted and have a pre-set 
     *          size.
     *********************************************************************/
    private Button createBottomButton() 
    {
        Button button = new Button();
        button.setPrefSize(150, 75);
        button.setStyle("-fx-background-color: lightblue;");
        return button;
    }

    /**********************************************************************
     * Method: Play Video
     * 
     * Purpose: To play a video when the door are clicked.
     *********************************************************************/
    private void playVideo(String videoFile) 
    {
        
        // Create a white rectangle to simulate a white screen
        Rectangle whiteScreen = new Rectangle(640, 480, Color.WHITE);

        // Create a new stage for the white screen
        Stage whiteScreenStage = new Stage();
        whiteScreenStage.setScene(new Scene(new StackPane(whiteScreen), 640, 480));
        whiteScreenStage.setTitle("White Screen");

        // Show the white screen
        whiteScreenStage.show();
    }
    
    /**********************************************************************
     * Method: lightningRound
     * 
     * Purpose: To start the lightning round once the player has completed
     *          4 rounds in the regular round and choses to move on.
     *********************************************************************/
    private void lightningRound()
    {
        // Creating the main BorderPane for the layout
        BorderPane borderPane2 = new BorderPane();
        borderPane2.setStyle("-fx-background-color: lightblue;");

        // Create an HBox for the door buttons with spacing
        HBox buttonBox2 = new HBox(10);
        buttonBox2.setAlignment(Pos.CENTER);

        /******************************************
         * Creating the Door Images
         *****************************************/
        Image door1Image2 = new Image("lightningDoor.png");
        ImageView door1ImageView2 = new ImageView(door1Image2);
        Image door2Image2 = new Image("lightningDoor.png");
        ImageView door2ImageView2 = new ImageView(door2Image2);
        Image door3Image2 = new Image("lightningDoor.png");
        ImageView door3ImageView2 = new ImageView(door3Image2);
        Image door4Image2 = new Image("lightningDoor.png");
        ImageView door4ImageView2 = new ImageView(door4Image2);
        
        
        /*****************************************
         * Creating the Title Image
         ****************************************/
        Image titleImage2 = new Image("lightningTitle.png");
        ImageView titleImageView2 = new ImageView(titleImage2);
        titleImageView2.setFitWidth(775);
        titleImageView2.setFitHeight(175);
        
        
        
        /******************************************
         * Creating Scoresheet Image
         *****************************************/
        Image scoresheetImage2 = new Image("lightningScoresheet.png");
        ImageView scoresheetImageView2 = new ImageView(scoresheetImage2);
        scoresheetImageView2.setFitWidth(260);
        scoresheetImageView2.setFitHeight(400);
        
        
        /******************************************
         * Creating the Door Buttons
         *****************************************/
        // Button 1
        Button door1 = createButton("door1", "video1.mp4");
        door1.setGraphic(door1ImageView2);
        door1ImageView2.setFitWidth(door1.getPrefWidth());
        door1ImageView2.setFitHeight(door1.getPrefHeight());
        // Button 2
        Button door2 = createButton("door2", "video2.mp4");
        door2.setGraphic(door2ImageView2);
        door2ImageView2.setFitWidth(door2.getPrefWidth());
        door2ImageView2.setFitHeight(door2.getPrefHeight());
        // Button 3
        Button door3 = createButton("door3", "video3.mp4");
        door3.setGraphic(door3ImageView2);
        door3ImageView2.setFitWidth(door3.getPrefWidth());
        door3ImageView2.setFitHeight(door3.getPrefHeight());
        // Button 4
        Button door4 = createButton("door4", "video4.mp4");
        door4.setGraphic(door4ImageView2);
        door4ImageView2.setFitWidth(door4.getPrefWidth());
        door4ImageView2.setFitHeight(door4.getPrefHeight());
        // Add buttons to the HBox
        buttonBox2.getChildren().addAll(door1, door2, door3, door4);
        
        
        
        
        /********************************************
         * Creating a label that displays the current
         * round the player is on.
        ********************************************/
        Label lightningRoundLabel = new Label();
        lightningRoundLabel.setText("Current Round: Lightning Round");
        lightningRoundLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");
        
        
        
        /********************************************
         * Creating a VBox (leftImagesBox) to hold the 
         * scoresheet, and another HBox (rightImagesBox) 
         * to hold the round label.
         ********************************************/
        // Create an VBox to hold the Jar
        VBox rightImagesBox = new VBox(10);
        // Placing the HBox and jar image in the VBox
        rightImagesBox.getChildren().addAll(lightningRoundLabel);
        // Center aligning the jar, buttons and label and adding spacing to it
        rightImagesBox.setAlignment(Pos.CENTER);
        rightImagesBox.setPadding(new Insets(20, 20, 20, 0));
        
        // Create a VBox to hold the scoresheet
        VBox leftImagesBox = new VBox(10);
        // Placing the scoresheet in the VBox
        leftImagesBox.getChildren().add(scoresheetImageView2);
        // Center aligning the scoresheet and adding spacing to it
        leftImagesBox.setAlignment(Pos.CENTER);
        leftImagesBox.setPadding(new Insets(20, 20, 20, 20));
        
        // Adding everything to the Borderpane
        borderPane2.setTop(titleImageView2);
        borderPane2.setMargin(titleImageView2, new Insets(20, 0, 0, 0));
        borderPane2.setAlignment(titleImageView2, Pos.CENTER);

        borderPane2.setCenter(buttonBox2);
        borderPane2.setLeft(leftImagesBox);
        borderPane2.setRight(rightImagesBox);
        
        BorderPane.setAlignment(buttonBox2, Pos.CENTER);
        
        // Create the scene with the BorderPane as the main layout
        Scene myScene = new Scene(borderPane2, 1450, 850);

        Stage secondaryStage = new Stage();
        // Set the scene for the primaryStage
        secondaryStage.setScene(myScene);
        secondaryStage.setTitle("Door Dash");
        secondaryStage.setWidth(1490);
        secondaryStage.setHeight(810);
        secondaryStage.setResizable(false);
        secondaryStage.show();
    }
}
