import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class Demo7 extends Application {
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Door Dash");

        // Create an HBox for the buttons with spacing
        HBox buttonBox = new HBox(10); // 10 pixels spacing (adjust as needed)

        // Create buttons
        Button door1 = createButton("door1", "video1.mp4", "video2.mp4");
        Button door2 = createButton("door2", "video3.mp4", "video4.mp4");
        Button door3 = createButton("door3", "video5.mp4", "video6.mp4");
        Button door4 = createButton("door4", "video7.mp4", "video8.mp4");

        // Add buttons to the HBox
        buttonBox.getChildren().addAll(door1, door2, door3, door4);

        // Create a Region for empty space (1 cm)
        Region emptySpace = new Region();
        emptySpace.setPrefWidth(1 * 50); // Assuming 1 cm = 50 pixels

        // Create a BorderPane to hold the HBox and empty space
        BorderPane borderPane = new BorderPane();
        borderPane.setTop(createTitleLabel()); // Add title label to the top
        borderPane.setCenter(buttonBox);
        borderPane.setLeft(emptySpace);
        BorderPane.setAlignment(buttonBox, Pos.CENTER);

        // Set the background color to light blue
        borderPane.setStyle("-fx-background-color: lightblue;");

        // Create the scene with the BorderPane as the root node
        Scene scene = new Scene(borderPane, 800, 600);

        // Set the scene for the primaryStage
        primaryStage.setScene(scene);

        // Show the primaryStage
        primaryStage.show();
    }

    private Button createButton(String buttonText, String video1, String video2) {
        Button button = new Button(buttonText);

        // Set dimensions
        button.setPrefSize(3 * 50, 5 * 50); // Assuming 1 cm = 50 pixels

        // Set white background when no image is present
        button.setStyle("-fx-background-color: white;");

        // Handle button click
        button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                // Play videos associated with the door (replace with your video playback implementation)
                playVideo(video1);
                playVideo(video2);
            }
        });

        return button;
    }

    //Plays a white screen for now
    private void playVideo(String videoFile) {
        // Create a white rectangle to simulate a white screen
        Rectangle whiteScreen = new Rectangle(640, 480, Color.WHITE);

        // Create a new stage for the white screen
        Stage whiteScreenStage = new Stage();
        StackPane whiteScreenPane = new StackPane(whiteScreen);

        // Set up the stage
        Scene whiteScreenScene = new Scene(whiteScreenPane, 640, 480);
        whiteScreenStage.setScene(whiteScreenScene);
        whiteScreenStage.setTitle("White Screen");

        // Show the white screen
        whiteScreenStage.show();
    }

    private Label createTitleLabel() {
        Label titleLabel = new Label("Door Dash");
        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");
        BorderPane.setAlignment(titleLabel, Pos.CENTER);
        return titleLabel;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
