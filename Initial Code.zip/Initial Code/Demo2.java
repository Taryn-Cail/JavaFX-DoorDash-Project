import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class Demo2 extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("JavaFX Game");

        // Create an HBox for the buttons with spacing
        HBox buttonBox = new HBox(10); // 10 pixels spacing (adjust as needed)

        // Create a StackPane as the root node
        StackPane root = new StackPane();

        // Set the background color to light blue
        root.setStyle("-fx-background-color: lightblue;");

        // Create buttons
        Button door1 = createButton("door1");
        Button door2 = createButton("door2");
        Button door3 = createButton("door3");
        Button door4 = createButton("door4");

        // Add buttons to the HBox
        buttonBox.getChildren().addAll(door1, door2, door3, door4);

        // Add the HBox to the StackPane with padding
        root.getChildren().add(buttonBox);
        StackPane.setMargin(buttonBox, new Insets(20)); // Adjust padding as needed

        // Create the scene with the StackPane as the root node
        Scene scene = new Scene(root, 800, 600);

        // Set the scene for the primaryStage
        primaryStage.setScene(scene);

        // Show the primaryStage
        primaryStage.show();
    }

    private Button createButton(String buttonText) {
        Button button = new Button(buttonText);
        
        // Set dimensions
        button.setPrefSize(3 * 50, 5 * 50); // Assuming 1 cm = 50 pixels

        // Set white background when no image is present
        button.setStyle("-fx-background-color: white;");

        return button;
    }
}
